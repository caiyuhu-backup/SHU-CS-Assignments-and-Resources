﻿package shu.ces.java.chap8;

public class Example8_10 {
   public static void main (String args[ ]) {
      String money = "89,235,678￥";
      System.out.print(money+"转化成数字："); 
      String s = money.replaceAll("[,\\p{Sc}]","") ; //"\\p{Sc}"可匹配任何货币符号
      
      long  number = Long.parseLong(s);
      System.out.println(number); 
      System.out.println(money);
   }
}