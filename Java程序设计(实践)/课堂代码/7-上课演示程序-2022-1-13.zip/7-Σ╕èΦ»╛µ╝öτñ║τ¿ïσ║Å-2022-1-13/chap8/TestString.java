package shu.ces.java.chap8;

public class TestString {
	public static void main(String[] args) {
		String s1="hello the world";
		String s2;
		s2="hello the world";
		String s3=new String("hello the world");
		
		TestString ts = new TestString();
		System.out.println(ts.toString());
		
		System.out.println(s1.equals(s2));
		System.out.println(s1.equals(s3));
		System.out.println(s1==s2);
		System.out.println(s1==s3);
	}
}