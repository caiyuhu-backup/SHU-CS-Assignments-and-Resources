package shu.ces.java.chap4;

class Sdate {
	int month;
	int day;
	int year;
	
	Sdate(int m, int d, int y) {
		month = m;
		day = d;
		year = y;
		System.out.println("日期是 " + month + "/" + day + "/" + year);
	}

	public static void main(String args[]) {
		Sdate s1, s2;
		s1 = new Sdate(11, 27, 1969);
		s2 = new Sdate(3, 3, 1973);
	}
}
