package shu.ces.java.chap4;

class Sdate2 {
	   int month;
	   int day=23;
	   int year;
	   
	   Sdate2(int m,int d,int y) {
		  month=m;
		  day=d;
		  year=y;
		  System.out.println("日期是 " + m + "/" + d + "/" + y + ".");
		}
	   
	   Sdate2(int m,int y) {  
	      month=m;
		  year=y;
		  System.out.println("日期是 " + m + "/" + day + "/" + y + ".");
	   }
	   
	   public static void main(String args[])
	   {
	      Sdate2 s1, s2;
	      s1=new Sdate2(3,3,1973);
	      s2=new Sdate2(12, 2020);
	   }
	}
