package shu.ces.java.chap4;

public class PrivateDemo {
	public int money;

	public int getMoney() {
		return money;
	}

	public static void main(String args[]) {
		PrivateDemo exa = new PrivateDemo();
		exa.money = 3000;
		int m = exa.getMoney();
		System.out.println("money=" + m);
	}
}
