package shu.ces.java.chap4;

class Pixel {
	int x;
	int y;

	void init(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public static void main(String args[]) {
		Pixel p = new Pixel();
		p.init(4, 3);
		System.out.println("二维空间中的点为：("+p.x+", "+ p.y + ")");
	}
}

