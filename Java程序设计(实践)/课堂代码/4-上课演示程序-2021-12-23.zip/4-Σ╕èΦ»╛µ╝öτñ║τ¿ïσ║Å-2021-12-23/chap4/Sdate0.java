package shu.ces.java.chap4;

class Sdate0 {
	  int month;
	  int day;
	  int year;
              
   public static void main(String args[ ]){
       Sdate0 s1;
       s1=new Sdate0();
       System.out.println("日期是：" + s1.month + "/" + s1.day + "/" + s1.year);
   } 
}

