package shu.ces.java.chap4;

public class Max {
	void max(int a, int b){
		System.out.println(a>b?a:b);
	}
	
	void max(double a, double b){
		System.out.println(a>b?a:b);
	}
	
	public static void main(String[] args){
		Max t = new Max();
		t.max(3, 4);
		
		double a = 4.43;
		double b = 7.5;
		t.max(a, b);
		
		int x=100;
		double y=300.25;
		t.max(x, y);
	}
}