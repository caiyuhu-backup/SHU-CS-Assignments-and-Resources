package shu.ces.java.chap4;

class Sdate1 {
	   int month;
	   int day;
	   int year;
	   
	   Sdate1(int m,int d,int y) {
		    month=m;
		    day=d;
		    year=y;
		    System.out.println("日期是" + m + "/" + d + "/" + y + ".");
		}
	   
	   Sdate1() {
//		   System.out.println("日期是" + month + "/" + day + "/" + year + ".");
	   }
	   
	   public static void main(String args[]){
	       Sdate1 s1,s2;
	       s1=new Sdate1(3,3,1973);
	       s2=new Sdate1();
	   }
	}
