﻿package shu.ces.java.chap3;

public class Example3_3 {
    public static void main(String args[]) {
       int math=65 ,english=70;
       if(math>60) { 
           System.out.println("数学及格了"); 
       }
       else { 
           System.out.println("数学不及格"); 
       }
       if(english>90) {
           System.out.println("英语是优");
       }
       else if (english >80) { 
           System.out.println("英语良好");
       }
       else {
    	   System.out.println("其他！");
       }
       System.out.println("我在学习if-else语句");  
    }
}
