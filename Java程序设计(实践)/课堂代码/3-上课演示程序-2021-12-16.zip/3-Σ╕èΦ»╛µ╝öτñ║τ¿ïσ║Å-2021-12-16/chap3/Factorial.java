package shu.ces.java.chap3;

public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long f=1;
		long result=0;
		
		for(int i=1;i<=10;i++) {
			f*=i;
			result+=f;
		}
		
		System.out.println(result);
	}

}
