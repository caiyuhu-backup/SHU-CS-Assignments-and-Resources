package shu.ces.java.chap3;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i1=10, i2=20;
		int i=(i2++);
		
		System.out.println("i="+i);
		System.out.println("i="+i2);
		
		i=(++i2);
		System.out.println("i="+i);
		System.out.println("i="+i2);
		
		i=(--i1);
		System.out.println("i="+i);
		System.out.println("i="+i1);
		
		i=(i1--);
		System.out.println("i="+i);
		System.out.println("i="+i1);
	}

}
