package shu.ces.java.chap3;

public class BreakAndContinue {
	public static void main(String args[]) {
		int identity = 4;
		
		for(int i=1; i<=10; i++){
			if (i==identity) {
				continue;
			}
			System.out.println("i=" + i);
		}
	}
}
