package shu.ces.java.chap4;

public class Book {
	String bookName;
	String authorName;
	int nopages;
	boolean available;

	Book(String bName, String aName, int Page, boolean a) {
		bookName = bName;
		authorName = aName;
		nopages = Page;
		available = a;
	}

	void isAvailable() {
		if (available == true)
			System.out.println("有这本书");
	}
}

