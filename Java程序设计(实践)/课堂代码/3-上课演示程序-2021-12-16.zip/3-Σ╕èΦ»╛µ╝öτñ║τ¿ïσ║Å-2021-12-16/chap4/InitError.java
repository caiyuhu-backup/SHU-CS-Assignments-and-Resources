package shu.ces.java.chap4;

public class InitError {
	    int x = 10, y; //y的默认值是0
	    
	    void f() {
	       int m=0; //m没有默认值
	       x = y+m; //无法通过编译，使用m之前未指定m的值
	       System.out.println(x);
	    }
	    
	    public static void main(String[] args) {
	    	InitError ie = new InitError();
	    	ie.f();
	    }
} 
