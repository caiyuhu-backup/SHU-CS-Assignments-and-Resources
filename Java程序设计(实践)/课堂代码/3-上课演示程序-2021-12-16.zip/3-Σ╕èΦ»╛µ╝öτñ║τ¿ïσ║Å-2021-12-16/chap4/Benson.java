package shu.ces.java.chap4;

public class Benson {
	int x = 100, y;
	
	void f() {
	    int x = 10;
	    y = x; 
	    System.out.println(y);
	    
	    y=this.x;
	    System.out.println(y);
	    System.out.println(x);
	    System.out.println(this.x);
	}
	
	public static void main(String[] args) {
		Benson benson = new Benson();
		benson.f();
	}
	
}
