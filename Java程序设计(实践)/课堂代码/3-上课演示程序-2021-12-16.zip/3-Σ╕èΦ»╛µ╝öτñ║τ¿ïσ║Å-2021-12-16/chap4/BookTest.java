package shu.ces.java.chap4;

public class BookTest {
	public static void main(String args[]) {
		Book objBook = new Book("Java Programming Design (Practice)", "Guobing Zou", 325, true);
		objBook.isAvailable();
		System.out.println("本课程推荐书作者："+objBook.authorName);
		System.out.println("本课程推荐书名称："+objBook.bookName);
	}
}
