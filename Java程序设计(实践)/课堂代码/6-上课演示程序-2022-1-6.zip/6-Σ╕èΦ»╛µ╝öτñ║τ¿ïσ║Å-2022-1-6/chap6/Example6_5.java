package shu.ces.java.chap6;

abstract class MotorVehicles1 {
   abstract void brake();
}

interface MoneyFare1 {
   void  charge();
}

interface ControlTemperature1 {
   void controlAirTemperature();
}

class Bus1 extends MotorVehicles1 implements MoneyFare1 {
    void brake() {
        System.out.println("公共汽车使用鼓式刹车技术");
    }
    
    public void charge() {
        System.out.println("公共汽车:一元/张,不计算公里数");
    }
} 

class Taxi1 extends MotorVehicles1 implements MoneyFare1,ControlTemperature1 {
    void brake() {
        System.out.println("出租车使用盘式刹车技术");
    }
    
    public  void charge() {
        System.out.println("出租车:2元/公里,起价3公里");
    }
    
    public void  controlAirTemperature() { 
        System.out.println("出租车安装了Hair空调");
    }
}

class Cinema1 implements MoneyFare1,ControlTemperature1 {
    public  void charge() {
        System.out.println("电影院:门票,十元/张");
    }
    
    public void  controlAirTemperature() { 
       System.out.println("电影院安装了中央空调");
    }
}

public class Example6_5 {
   public static void main(String args[]) {
       Bus1  bus101 = new Bus1();
       Taxi1 buleTaxi = new Taxi1();
       Cinema1 redStarCinema = new Cinema1();
       
       bus101.brake(); 
       bus101.charge();
       
       buleTaxi.brake();
       buleTaxi.charge();
       buleTaxi.controlAirTemperature();
       
       redStarCinema.charge();
       redStarCinema.controlAirTemperature();
   }
}