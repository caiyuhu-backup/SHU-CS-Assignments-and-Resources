package shu.ces.java.chap6;

public class ComputerS implements Computable {
	int number;
	
	public int compute(int a, int b){
		number = a+b;
		
		return number;
	}
	
	public void display(){
		System.out.println("The result of sum:"+number);
	}
}
