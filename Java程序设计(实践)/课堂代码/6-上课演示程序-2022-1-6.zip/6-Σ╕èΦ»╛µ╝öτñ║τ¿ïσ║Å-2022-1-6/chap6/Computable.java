package shu.ces.java.chap6;

public interface Computable {
	int MAX = 100;
	int compute(int a, int b);
}
