package shu.ces.java.chap6;

public class Computer {
	public static void main(String[] args){
		ComputerS cs = new ComputerS();
		ComputerM cm = new ComputerM();
		
		int a = 10;
		int b = 20;
		
		cs.compute(a, b);
		cm.compute(a, b);
		
		cs.display();
		cm.display();
	}
}
