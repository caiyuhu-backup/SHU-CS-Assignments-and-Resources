﻿package shu.ces.java.chap6;

interface MoneyFare {
   void  charge();
}

interface ControlTemperature {
   void controlAirTemperature();
}

class Bus implements MoneyFare {
    public void charge() {
        System.out.println("公共汽车:一元/张,不计算公里数");
    }
} 

class Taxi implements MoneyFare,ControlTemperature {  
    public  void charge() {
        System.out.println("出租车:2元/公里,起价3公里");
    }
    
    public void  controlAirTemperature() { 
        System.out.println("出租车安装了Hair空调");
    }
}

class Cinema implements MoneyFare,ControlTemperature {
    public  void charge() {
        System.out.println("电影院:门票,十元/张");
    }
    
    public void  controlAirTemperature() { 
       System.out.println("电影院安装了中央空调");
    }
}

public class Example6_2 {
   public static void main(String args[]) {
       Bus  bus101 = new Bus();
       Taxi buleTaxi = new Taxi();
       Cinema redStarCinema = new Cinema();
       
       bus101.charge();
       
       buleTaxi.charge();
       buleTaxi.controlAirTemperature();
       
       redStarCinema.charge();
       redStarCinema.controlAirTemperature();
   }
}