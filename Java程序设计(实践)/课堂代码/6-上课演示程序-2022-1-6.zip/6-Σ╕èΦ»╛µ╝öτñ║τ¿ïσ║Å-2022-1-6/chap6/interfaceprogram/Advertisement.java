﻿package shu.ces.java.chap6.interfaceprogram;

public interface Advertisement { //接口
      public void showAdvertisement();
      public String getCorpName();
}