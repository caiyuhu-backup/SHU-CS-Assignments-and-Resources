﻿package shu.ces.java.chap6.interfaceprogram;

public class WhiteCloudCorp implements Advertisement { //PhilipsCorp实现Avertisement接口
   public void showAdvertisement(){
      System.out.println("@@@@@@@@@@@@@@@@@@@@@@");
      System.out.printf("飞机中的战斗机，哎yes!\n");
      System.out.println("@@@@@@@@@@@@@@@@@@@@@@");
   }
   public String getCorpName() {
      return "白云有限公司" ; 
   }
}