﻿package shu.ces.java.chap6.interfaceprogram;

public class BlackLandCorp implements Advertisement { 
   public void showAdvertisement(){
      System.out.println("**************");
      System.out.printf("劳动是爹\n土地是妈\n");
      System.out.println("**************");
   }
   public String getCorpName() {
      return "黑土集团" ; 
   }
}