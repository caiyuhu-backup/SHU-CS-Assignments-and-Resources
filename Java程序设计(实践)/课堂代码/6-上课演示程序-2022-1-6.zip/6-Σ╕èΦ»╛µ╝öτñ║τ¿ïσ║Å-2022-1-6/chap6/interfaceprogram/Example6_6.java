﻿package shu.ces.java.chap6.interfaceprogram;

public class Example6_6 {
   public static void main(String args[]) {
      AdvertisementBoard board = new AdvertisementBoard(); 
      board.show(new WhiteCloudCorp());
      board.show(new BlackLandCorp());
   }
}