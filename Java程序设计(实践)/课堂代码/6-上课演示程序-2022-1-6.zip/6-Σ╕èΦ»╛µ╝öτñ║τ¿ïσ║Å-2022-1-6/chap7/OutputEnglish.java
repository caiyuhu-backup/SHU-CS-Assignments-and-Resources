﻿package shu.ces.java.chap7;

public class OutputEnglish extends OutputAlphabet {
   public void output() {
      for(char c='a';c<='z';c++) {
         System.out.printf("%3c",c);
      }  
   } 
}