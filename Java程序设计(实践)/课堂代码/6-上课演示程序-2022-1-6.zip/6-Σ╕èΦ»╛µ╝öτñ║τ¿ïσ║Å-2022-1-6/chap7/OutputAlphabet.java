﻿package shu.ces.java.chap7;

abstract class OutputAlphabet {
   public abstract void output();
}