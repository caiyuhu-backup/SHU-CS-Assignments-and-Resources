﻿package shu.ces.java.chap7;

public class ShowBoard {
   void showMess(OutputAlphabet show) {
     show.output();   
   } 
}