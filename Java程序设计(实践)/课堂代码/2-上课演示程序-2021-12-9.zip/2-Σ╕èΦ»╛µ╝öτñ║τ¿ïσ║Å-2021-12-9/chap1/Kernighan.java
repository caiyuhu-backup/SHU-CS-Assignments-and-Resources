package shu.ces.java.chap1;

public class Kernighan {
    public static void main(String args[]){
        int sum=0,i=0;
        for(i=1;i<=100;i++){
            sum=sum+i;
        }
        System.out.println("从1开始的100项之和为："+sum);
    }
}
