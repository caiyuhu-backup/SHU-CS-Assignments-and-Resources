package shu.ces.java.chap1;

public class ComputeEven 
{
    public static void main(String args[])
    {
        int sum=0,i=0, flag=0;
        for(i=0;i<=20;i=i+2)
        {
            flag++;
        	if(i%2==0) {
            	System.out.println(i+"是偶数！");
            	sum=sum+i;
            }    		
        }
        System.out.println("所有偶数之和为："+sum);
        System.out.println("测试的次数："+flag);
    }
}
