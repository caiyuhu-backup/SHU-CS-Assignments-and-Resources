package shu.ces.java.chap2;

public class Test {
	int i=2;
	
	public static void main(String[] args) {
		Test test = new Test();
		test.testMethod();
	}
	
	public void testMethod() {
//		int i;
		int j=i+5;
		
		float x=(float)0.123;
		double y=0.123;
		
		int n=(int) 23.7;
		System.out.println(n);
		
		System.out.println(j);
	}
}
