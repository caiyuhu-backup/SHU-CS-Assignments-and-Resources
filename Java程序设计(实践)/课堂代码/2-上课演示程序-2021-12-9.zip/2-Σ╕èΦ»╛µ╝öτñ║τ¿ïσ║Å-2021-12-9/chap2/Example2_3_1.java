package shu.ces.java.chap2;

import java.util.Scanner;
public class Example2_3_1 {
    public static void main (String args[ ]){
        System.out.println("请输入若干个数，每输入一个数回车确认");
        System.out.println("最后输入非数字结束输入操作");
        Scanner reader=new Scanner(System.in);
      
        double sum = 0;
        double x = 0;
        int counter = 0;
        
        while(reader.hasNextDouble()){
        	x = reader.nextDouble();     
        	sum=sum+x;
        	counter++;
        }
       
        System.out.println("共输入有效值"+counter+"次，总和为："+sum); 
    }
}



