package shu.ces.java.chap2.Example4_8_1;

class Circular { 
    Circle bottom;
    double height;
    Circular(Circle c,double h) { //构造方法，将Circle类的实例的引用传递给bottom
       bottom = c;
       height = h;
    }
    double getVolme() {
       return bottom.getArea()*height/3.0;
    }
    double getBottomRadius() {
       return bottom.getRadius();
    }
    public void setBottomRadius(double r){
       bottom.setRadius(r);
    } 
}


class Circle { 
    double radius,area;
    Circle(double r) {
       radius = r;
    }
    void setRadius(double r) {
        radius=r;
    } 
    double getRadius(){
        return radius;
    }
    double getArea(){
        area=3.14*radius*radius;
        return area;
    }
}

public class Example4_8_1 {
	   public static void main(String args[]) {
	       Circle circle = new Circle(10);            //【代码1】
	       System.out.println("main方法中circle的引用:"+circle); 
	       System.out.println("main方法中circle的半径"+circle.getRadius()); 
	       Circular circular = new Circular(circle,20);         //【代码2】
	       System.out.println("circular圆锥的bottom的引用:"+circular.bottom); 
	       System.out.println("圆锥的bottom的半径:"+circular.getBottomRadius()); 
	       System.out.println("圆锥的体积:"+circular.getVolme());
	       double r = 8888;
	       System.out.println("圆锥更改底圆bottom的半径:"+r);
	       circular.setBottomRadius(r);           //【代码3】   
	       System.out.println("圆锥的bottom的半径:"+circular.getBottomRadius()); 
	       System.out.println("圆锥的体积:"+circular.getVolme()); 
	       System.out.println("main方法中circle的半径:"+circle.getRadius()); 
	       System.out.println("main方法中circle的引用将发生变化");
	       circle = new Circle(1000); //重新创建circle 【代码4】
	       System.out.println("现在main方法中circle的引用:"+circle); 
	       System.out.println("main方法中circle的半径:"+circle.getRadius()); 
	       System.out.println("但是不影响circular圆锥的bottom的引用");
	       System.out.println("circular圆锥的bottom的引用:"+circular.bottom); 
	       System.out.println("圆锥的bottom的半径:"+circular.getBottomRadius()); 
	    }
	}