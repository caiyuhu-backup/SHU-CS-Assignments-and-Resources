package shu.ces.java.chap5;

public class Other {
	public static void main(String[] args){
		C c = new C();
		
		c.VarA="SHU";
		c.VarB="FDU";
		c.VarC="SJTU";
		
		System.out.println(c.getVarA());
		System.out.println(c.getVarB());
		System.out.println(c.getVarC());
	}
}
