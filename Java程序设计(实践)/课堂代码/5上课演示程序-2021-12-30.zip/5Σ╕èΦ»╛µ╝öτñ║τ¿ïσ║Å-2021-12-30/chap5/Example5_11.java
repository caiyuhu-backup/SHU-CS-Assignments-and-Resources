package shu.ces.java.chap5;

class EspecialCar {
	void cautionSound() {
	}
}

class PoliceCar extends EspecialCar {
	void cautionSound() {
		System.out.println("zhua..zhua..zhua...");
	}
}

class AmbulanceCar extends EspecialCar {
	void cautionSound() {
		System.out.println("jiu..jiu..jiu...");
	}
}

class FireCar extends EspecialCar {
	void cautionSound() {
		System.out.println("huo..huo..huo...");
	}
}

public class Example5_11 {
	public static void main(String args[]) {
		// car是警车的上转型对象
		EspecialCar car = new PoliceCar();
		car.cautionSound();
		// car是救护车的上转型对象
		car = new AmbulanceCar();
		car.cautionSound();
		// car是消防车的上转型对象
		car = new FireCar();
		car.cautionSound();
	}
}

