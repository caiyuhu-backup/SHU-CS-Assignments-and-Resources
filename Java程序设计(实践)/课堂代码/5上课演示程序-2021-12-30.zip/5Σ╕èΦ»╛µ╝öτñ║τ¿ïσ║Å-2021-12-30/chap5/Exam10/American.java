package shu.ces.java.chap5.Exm10;

public class American extends People {
	   int height=1000;
	   
		void showBodyMess() {
	      System.out.println("bodyHeight:"+height+"cm"+" bodyWeight:"+weight+"kg"); 
	   }  
		
	   void speakEnglish() {
	      System.out.println("I am Amerian");
	   }
	}