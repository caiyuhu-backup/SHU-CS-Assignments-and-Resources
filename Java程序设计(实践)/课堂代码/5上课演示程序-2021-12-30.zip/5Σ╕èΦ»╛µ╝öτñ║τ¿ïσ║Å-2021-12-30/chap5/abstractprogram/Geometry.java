﻿package shu.ces.java.chap5.abstractprogram;

public abstract class Geometry { //如果使用接口需用interface来定义Geometry。
     public abstract double getArea();
}







