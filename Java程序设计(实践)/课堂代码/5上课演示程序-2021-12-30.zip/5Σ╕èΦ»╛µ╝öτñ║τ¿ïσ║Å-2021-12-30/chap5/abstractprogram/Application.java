﻿package shu.ces.java.chap5.abstractprogram;

public class Application{
    public static void main(String args[]){
        Pillar pillar;
       
        pillar =new Pillar (new Rectangle(12,22), 58);  //pillar是具有矩形底的柱体
        System.out.println("矩形底的柱体的体积"+pillar.getVolume());
        
        pillar =new Pillar (new Circle(10), 58); //pillar是具有圆形底的柱体
        System.out.println("圆形底的柱体的体积"+pillar.getVolume());
    }
} 