package shu.ces.java.chap5;

public class A {
	protected String VarA;
	
	protected void setVarA(String VarA){
		this.VarA=VarA;
	}
	
	protected String getVarA(){
		return this.VarA;
	}
}
