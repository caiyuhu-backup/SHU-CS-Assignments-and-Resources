package shu.ces.java.chap5.Exam2;

public class B extends A {
    double y;
    
    public void setY(int y) {   
    	//非法，子类没有继承x
    	//this.y=y+x;
    	this.y=y;
    }
    
    public double getY() {
       return y;
    }
}

