package shu.ces.java.chap5;

public class B extends A {
	protected String VarB;
	
	protected void setVarB(String VarB){
		this.VarB=VarB;
	}
	
	protected String getVarB(){
		return this.VarB;
	}
}
