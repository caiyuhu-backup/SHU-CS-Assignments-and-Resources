package shu.ces.java.chap5;

public class FatherClass {
	String name;
	char gender;
	protected int age;
	public String school;
	
	String getName() {
		return name;
	}
	
	private void setName(String name) {
		this.name = name;
	}
	
	char isGender() {
		return gender;
	}
	
	void setGender(char gender) {
		this.gender = gender;
	}
	
	protected int getAge() {
		return age;
	}
	
	protected void setAge(int age) {
		this.age = age;
	}
	
	public String getSchool() {
		return school;
	}
	
	public void setSchool(String school) {
		this.school = school;
	}
}
