package shu.ces.java.chap5;

public class C extends B {
	protected String VarC;
	
	protected void setVarC(String VarC){
		this.VarC=VarC;
	}
	
	protected String getVarC(){
		return this.VarC;
	}
	
	public static void main(String[] args){
		C c = new C();
		
		c.VarA="SHU";
		c.VarB="FDU";
		c.VarC="SJTU";
		
		System.out.println(c.getVarA());
		System.out.println(c.getVarB());
		System.out.println(c.getVarC());
	}
}
