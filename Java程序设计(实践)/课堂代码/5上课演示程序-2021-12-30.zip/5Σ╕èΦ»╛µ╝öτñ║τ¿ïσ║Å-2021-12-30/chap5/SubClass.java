package shu.ces.java.chap5;

public class SubClass extends FatherClass {
	private String address;

	private String getAddress() {
		return address;
	}

	private void setAddress(String address) {
		this.address = address;
	}
	
	public static void main(String[] args){
		SubClass sc = new SubClass();
		
		sc.name="Guobing Zou";
		sc.gender='男';
		sc.age=39;
		sc.school="Shanghai University";
		sc.address="99 Shangda Road, Baoshan District, Shanghai, China";
		
		System.out.println(sc.getName());
		System.out.println(sc.isGender());
		System.out.println(sc.getAge());
		System.out.println(sc.getSchool());
		System.out.println(sc.getAddress());
	}
}
