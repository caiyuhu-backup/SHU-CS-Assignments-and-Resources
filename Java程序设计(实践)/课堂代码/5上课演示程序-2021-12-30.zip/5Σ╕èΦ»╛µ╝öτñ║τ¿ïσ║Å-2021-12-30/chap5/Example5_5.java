package shu.ces.java.chap5;

class A1 {
     protected float computer(float x,float y) {
       return x+y;
    }
    
    public int g(int x,int y) {
       return x+y;
    }
}

class B1 extends A1 {
	 protected float computer(float x,float y) {
       return x*y;
    }  
}

public class Example5_5 {
    public static void main(String args[]) {
      B1 b1=new B1();
      
      double result=b1.computer(8,9); //b调用重写的方法
      System.out.println("调用重写方法得到的结果:"+result);   
      
      int m=b1.g(12,8); //b调用继承的方法
      System.out.println("调用继承方法得到的结果:"+m);  
    } 
}