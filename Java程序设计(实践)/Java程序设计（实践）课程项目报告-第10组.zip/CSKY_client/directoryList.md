|-- CSKY_Client
    |-- src
        |-- App.vue -- 主页面
        |-- main.js -- 整体配置
        |-- api -- 接口配置
        |-- assets -- 静态资源
        |-- components -- 普通组件
        |-- pages -- 路由组件
        |-- routers -- 路由配置
        |-- store -- vuex配置
        |-- utils -- 工具包
