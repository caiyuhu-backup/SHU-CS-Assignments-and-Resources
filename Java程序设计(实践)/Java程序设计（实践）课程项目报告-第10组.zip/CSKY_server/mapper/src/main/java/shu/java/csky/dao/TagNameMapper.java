package shu.java.csky.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import shu.java.csky.entity.TagName;

/**
 * @author 20121706
 */
public interface TagNameMapper extends BaseMapper<TagName> {
}
