package shu.java.csky.dao;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import shu.java.csky.entity.Teachers;

public interface TeachersMapper extends BaseMapper<Teachers> {
}