package shu.java.csky.dao;

import shu.java.csky.entity.Likes;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author Silence
* @description 针对表【likes】的数据库操作Mapper
* @createDate 2022-02-22 20:45:32
* @Entity shu.java.csky.entity.Likes
*/
public interface LikesMapper extends BaseMapper<Likes> {

}




