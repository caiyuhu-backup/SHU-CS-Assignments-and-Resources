package shu.java.csky.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import shu.java.csky.entity.Cs;

public interface CsMapper extends BaseMapper<Cs> {
}