package shu.java.csky.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import shu.java.csky.entity.School;

public interface SchoolMapper extends BaseMapper<School> {
}