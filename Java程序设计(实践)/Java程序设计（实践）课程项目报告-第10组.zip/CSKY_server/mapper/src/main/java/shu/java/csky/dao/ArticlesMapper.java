package shu.java.csky.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import shu.java.csky.entity.Articles;

public interface ArticlesMapper extends BaseMapper<Articles> {
}