package shu.java.csky.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import shu.java.csky.entity.EmailCode;

/**
 * @author 20121706
 */
public interface EmailCodeMapper extends BaseMapper<EmailCode> {
}
