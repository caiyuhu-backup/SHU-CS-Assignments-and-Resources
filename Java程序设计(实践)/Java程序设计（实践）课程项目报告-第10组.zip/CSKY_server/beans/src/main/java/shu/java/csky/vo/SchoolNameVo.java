package shu.java.csky.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author 20121706
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SchoolNameVo {
    private Integer sid;
    private String sname;
}
