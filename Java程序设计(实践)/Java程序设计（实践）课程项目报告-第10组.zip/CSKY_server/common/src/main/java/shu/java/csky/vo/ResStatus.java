package shu.java.csky.vo;

public class ResStatus {
    public static final int OK = 200; // 成功
    public static final int NO = 201; // 失败
}

