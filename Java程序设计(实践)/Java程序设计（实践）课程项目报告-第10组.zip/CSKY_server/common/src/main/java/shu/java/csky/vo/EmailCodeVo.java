package shu.java.csky.vo;

import lombok.Data;

/**
 * @author 20121706
 */
@Data
public class EmailCodeVo {
    private String eid;
    private String email;
}
