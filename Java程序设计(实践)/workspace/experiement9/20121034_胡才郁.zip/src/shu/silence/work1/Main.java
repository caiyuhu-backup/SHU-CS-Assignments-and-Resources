package shu.silence.work1;

/**
 * @author: Silence
 * @date: 2022/3/2 8:56
 * @description:
 */
public class Main {
    public static void main(String args[]) {
        WindowMouse win=new WindowMouse();
        win.setTitle("处理鼠标事件");
        win.setBounds(10,10,460,360);
    }
}
