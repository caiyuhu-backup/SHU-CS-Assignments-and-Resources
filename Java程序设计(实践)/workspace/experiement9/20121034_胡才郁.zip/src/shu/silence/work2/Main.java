package shu.silence.work2;

public class Main {
   public static void main(String args[]) {
      WindowInput win=new WindowInput();
      win.setTitle("带输入对话框的窗口"); 
      win.setBounds(80,90,200,300);
      win.setLocationRelativeTo(null);
   }
}