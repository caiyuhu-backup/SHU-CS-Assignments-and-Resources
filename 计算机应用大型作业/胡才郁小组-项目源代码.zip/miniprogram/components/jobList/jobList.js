// components/jobList/jobList.js
const db = wx.cloud.database({
  env: 'mnb-recruiment-8g6adanb0a6276b2'
})
const dayjs = require('../../miniprogram_npm/miniprogram_npm/dayjs/index')

Component({
    /**
     * 组件的属性列表
     */
    properties: {
        jobList: {
            type: Array,
            value: []
        }
    },

    /**
     * 组件的初始数据
     */
    data: {

    },

    /**
     * 组件的方法列表
     */
    methods: {
        toJobDetailPage(e) {
          const userInfo = wx.getStorageSync('userInfo')
          const job = this.data.jobList[e.currentTarget.dataset.index]
          const jobId = job._id
          // 已经登录
          if (userInfo) {
            db.collection('work_record_job').where({jobId: jobId, userId: userInfo.userId}).get().then(res=>{
              if (res.data.length === 0) {
                db.collection('work_record_job').add({
                  data: {
                    jobId,
                    userId: userInfo.userId,
                    viewTime: dayjs(new Date()).format("YYYY-MM-DD"),
                    updateTime: new Date(),
                    jobName: job.jobName,
                    salary: job.salary,
                    content: job.content,
                    location: job.location,
                    remainNum: job.remainNum,
                    needNum: job.needNum
                  }
                })
              } else {
                db.collection('work_record_job').where({jobId: jobId, userId: userInfo.userId}).update({
                  data: {
                    jobId,
                    userId: userInfo.userId,
                    viewTime: dayjs(new Date()).format("YYYY-MM-DD"),
                    updateTime: new Date(),
                    jobName: job.jobName,
                    salary: job.salary,
                    content: job.content,
                    location: job.location,
                    remainNum: job.remainNum,
                    needNum: job.needNum
                  }
                })
              }
            })
          }
          wx.navigateTo({
              url: '/pages/job-detail/job-detail?id=' + jobId
          })
        },
    }
})
