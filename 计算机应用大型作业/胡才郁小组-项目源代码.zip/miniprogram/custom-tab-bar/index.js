// custom-tab-bar/index.js
import { storeBindingsBehavior } from 'mobx-miniprogram-bindings'
import { store } from '../store/store'

Component({
  options: {
    styleIsolation: 'shared'
  },
  behaviors: [storeBindingsBehavior],
  storeBindings: {
    store,
    fields: {
      active: 'activeTabBarIndex'
    },
    actions: {
      updateActive: 'updateActiveTabBarIndex'
    },
  },
  observers: {
  },
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    "list": [
        {
            "pagePath": "/pages/home/home",
            "text": "首页",
            "iconPath": "/images/tabs/home.png",
            "selectedIconPath": "/images/tabs/home-active.png"
        },
        {
            "pagePath": "/pages/tutorial/tutorial",
            "text": "帮助",
            "iconPath": "/images/tabs/local.png",
            "selectedIconPath": "/images/tabs/local-active.png"
        },
        {
            "pagePath": "/pages/message/message",
            "text": "消息",
            "iconPath": "/images/tabs/message.png",
            "selectedIconPath": "/images/tabs/message-active.png"
        },
        {
            "pagePath": "/pages/center/center",
            "text": "我的",
            "iconPath": "/images/tabs/center.png",
            "selectedIconPath": "/images/tabs/center-active.png"
        }
    ]
  },

  /**
   * 组件的方法列表
   */
  methods: {
    onChange(event) {
        // event.detail 的值为当前选中项的索引
        // this.setData({ active: event.detail })
        wx.switchTab({
            url: this.data.list[event.detail].pagePath,
        })
        this.updateActive(event.detail)
    },
  }
})