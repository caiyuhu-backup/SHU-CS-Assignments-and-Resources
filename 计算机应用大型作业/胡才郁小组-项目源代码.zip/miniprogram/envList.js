module.exports = {
    envList: [{
      envId:'mnb-recruiment-8g6adanb0a6276b2'
    }]
  }