#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int index = 0;
    for(;;)
    {
        index++;
    }
    return 0;
}
