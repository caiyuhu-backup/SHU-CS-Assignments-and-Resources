//
// Created by Silence on 2022/4/21.
//

#ifndef DS_UTILS_H
#define DS_UTILS_H

class Utils {
public:
    static int getBlockNum(int num);
//    static int handleTubeNum(int num, bool& status);
};

#endif //DS_UTILS_H
