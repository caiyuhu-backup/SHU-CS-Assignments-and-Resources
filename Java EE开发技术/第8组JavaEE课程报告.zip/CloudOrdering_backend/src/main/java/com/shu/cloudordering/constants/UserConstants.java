package com.shu.cloudordering.constants;

/**
 * @author itbear-shu-20121706
 * @date 2022/4/4 12:56
 */
public class UserConstants {
    public static final String USER_NICK_NAME_PREFIX = "User_";
    public static final String USER_REAL_NAME_PREFIX = "贪吃的_";
}
