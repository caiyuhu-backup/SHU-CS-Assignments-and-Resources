package com.shu.cloudordering.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shu.cloudordering.model.entity.ExpPhone;

public interface ExpPhoneMapper extends BaseMapper<ExpPhone> {
}
