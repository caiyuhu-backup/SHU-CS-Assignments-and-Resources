package com.shu.cloudordering.utils;

import com.huaban.analysis.jieba.JiebaSegmenter;

/**
 * @author: Silence
 * @date: 2022/6/1 13:56
 * @description:
 */
public class Jieba {
    public JiebaSegmenter segmenter = new JiebaSegmenter();
}
