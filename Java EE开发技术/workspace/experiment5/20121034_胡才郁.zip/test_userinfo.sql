INSERT INTO test.userinfo (id, username, password) VALUES (1, '胡才郁', '123');
INSERT INTO test.userinfo (id, username, password) VALUES (2, '张俊雄', '123');
